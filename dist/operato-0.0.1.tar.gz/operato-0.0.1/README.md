# Welcome to `operato`!

This python package was developed to automate the creation of Radioss input files.
The repository and its initial structure was forked from 
(https://github.com/nawijn/operato) and expanded.


